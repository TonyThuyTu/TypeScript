import { sum, multiply, sortAsc, sortDesc } from "./math";

console.log(sum(1, 2, 3, 4, 5)); 
console.log(multiply(1, 2, 3, 4, 5));
console.log(sortAsc(5, 4, 3, 2, 1));
console.log(sortDesc(5, 4, 3, 2, 1));