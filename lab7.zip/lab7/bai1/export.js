"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var math_1 = require("./math");
console.log((0, math_1.sum)(1, 2, 3, 4, 5));
console.log((0, math_1.multiply)(1, 2, 3, 4, 5));
console.log((0, math_1.sortAsc)(5, 4, 3, 2, 1));
console.log((0, math_1.sortDesc)(5, 4, 3, 2, 1));
